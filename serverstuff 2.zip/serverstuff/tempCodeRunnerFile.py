    intersection_matrix = results['reporters']['intersection_matrix'][0]
    total_steps = results['reporters']['total_steps'